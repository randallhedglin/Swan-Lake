//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by swanlake.rc
//
#define MANIFEST_RESOURCE_ID            1
#define IDS_STRING                      1
#define IDB_LOADINGSCREEN               101
#define IDB_LOADINGBAR1                 102
#define IDB_LOADINGBAR2                 103
#define IDB_LOADINGBAR3                 104
#define IDB_LOADINGBAR4                 105
#define IDI_APPICON                     106
#define IDB_SCREENSHOT                  107
#define IDB_LOGOBUTTON                  108
#define IDD_ABOUTDIALOG                 110
#define IDB_APPICONIMAGE                115
#define IDB_LOGOBUTTON2                 117
#define IDD_PURCHDIALOG                 118
#define IDB_ASPLOGO                     120
#define IDB_DAYSLEFT                    121
#define IDB_EXPIRED                     122
#define IDB_LOGOBUTTON3                 123
#define IDB_LOGOBUTTON4                 124
#define IDB_CCARDS1                     126
#define IDB_CCARDS2                     127
#define IDD_CONFIGDIALOG                1000
#define IDC_ENVIRONMENT                 1001
#define IDC_NUMSWANS                    1003
#define IDC_NUMTURTLES                  1004
#define IDC_NUMDFLIES                   1005
#define IDC_NUMFISH                     1006
#define IDC_NUMBIRDS                    1007
#define IDC_FOGHAZE                     1008
#define IDC_LENSFLARES                  1009
#define IDC_RIPPLES                     1010
#define IDC_CLOCK                       1011
#define IDC_GRAPHICS                    1012
#define IDC_RESOLUTIONS                 1013
#define IDC_TEXSMOOTH                   1014
#define IDC_SHADESMOOTH                 1015
#define IDC_AUDIO                       1016
#define IDC_ENABLEMUSIC                 1017
#define IDC_ENABLESOUND                 1018
#define IDC_3DSOUND                     1019
#define IDC_MASTERVOL                   1020
#define IDC_MUSICVOL                    1021
#define IDC_SOUNDVOL                    1022
#define IDC_WAVEBREAK                   1023
#define IDC_OPENABOUT                   1023
#define IDC_ADVANCED                    1024
#define IDC_PRIORITY                    1025
#define IDC_TRIPLEBUFFER                1026
#define IDC_PURCHASE                    1027
#define IDC_DEFAULTS                    1028
#define HIDC_HELP                       1029
#define IDC_SCROLLBAR1                  1030
#define IDC_BUTTON1                     1031
#define IDC_HOMEPAGE                    1031
#define IDC_DAYSLEFT                    1031
#define IDC_README                      1032
#define IDC_LICENSE                     1033
#define IDC_SWANLAKEICON2               1034
#define IDC_SWANLAKEICON                1035
#define IDC_ASPBUTTON                   1036
#define IDC_ORDERNOW                    1037
#define IDC_WB_SL_LOGO                  1038
#define IDC_SLLOGO                      1038
#define IDC_WBLOGO                      1039
#define IDC_VIEWFORM                    1040
#define IDC_PRINTFORM                   1041
#define IDC_CARDS1                      1042
#define IDC_CARDS2                      1043
#define IDC_DAYSLEFTTEXT                1045

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        128
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1046
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
